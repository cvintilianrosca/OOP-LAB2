package memory_references.in_methods;

public class StudentTest {

    public static void main(String[] args) {
        int a;

        // TODO: comment this one
        a = 0;
        System.out.println(a);
    }

}
