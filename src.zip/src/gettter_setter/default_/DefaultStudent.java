package gettter_setter.default_;

public class DefaultStudent {
    String firstName;
    String lastName;
    Integer age;
    boolean isHappy;
}
