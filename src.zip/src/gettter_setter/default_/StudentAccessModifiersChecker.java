package gettter_setter.default_;

public class StudentAccessModifiersChecker {
    public static void main(String[] args) {
        DefaultStudent defaultStudent = new DefaultStudent();

    }
}
