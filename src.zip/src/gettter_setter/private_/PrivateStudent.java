package gettter_setter.private_;

public class PrivateStudent {
    private String firstName;
    private String lastName;
    private Integer age;
    private boolean isHappy;



}
