package gettter_setter.private_;


public class StudentAccessModifiersChecker {
    public static void main(String[] args) {
        PrivateStudent privateStudent = new PrivateStudent();

    }
}
