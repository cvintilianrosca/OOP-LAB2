package gettter_setter.public_;

public class PublicStudent {
    public String firstName;
    public String lastName;
    public Integer age;
    public boolean isHappy;
}
