package gettter_setter.protected_;

public class ProtectedStudent {
    protected String firstName;
    protected String lastName;
    protected Integer age;
    protected boolean isHappy;
}
