package gettter_setter.protected_;


public class StudentAccessModifiersChecker {
    public static void main(String[] args) {
        ProtectedStudent protectedStudent = new ProtectedStudent();
    }
}
