package objects_method;

public class StudentTest {
    public static void main(String[] args) {

        Student student = new Student();

        // How many methods are in the student class?
        System.out.println(student.toString());

    }
}


/**
 * How many methods are in the Student class?
 * - 0? https://www.youtube.com/watch?v=2Z4m4lnjxkY&ab_channel=SkipEverling
 *
 */
class Student extends Object {

//    @Override
//    public String toString() {
//        return "Pantelimon Ghiu";
//    }
}