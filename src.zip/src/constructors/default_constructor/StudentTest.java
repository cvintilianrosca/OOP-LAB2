package constructors.default_constructor;

public class StudentTest {

    public static void main(String[] args) {
        final Student student = new Student();
    }

}


/**
 * Hey, there is no constructor here : ((
 * Why is it working, hmmmm
 */
class Student {

}